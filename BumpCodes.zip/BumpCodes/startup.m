pwd;
addpath ../BumpCodes/
addpath ../BumpCodes/mex/
addpath ../BumpCodes/Problems/


