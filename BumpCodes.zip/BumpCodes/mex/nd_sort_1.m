% Non-dominated sorting
function [fronts,front_clm] = nd_sort_1(f_all,id)
idx=[];
if isempty(f_all) 
	fronts = [];
	return
end
if isempty(id)
	fronts = [];
	return
end
[fronts,front_clm] = nd_sort(id, f_all);

for i = 1:size(fronts,2)
    if i==1
        [ranks, dist] = sort_crowding(f_all, fronts(i).f);
        idx = [idx;ranks];
    else
        idx = [idx;fronts(i).f'];
    end
end

return



% implementation of non-dominated sorting
function [F,front_clm] = nd_sort(feasible,f_all)

front = 1;
F(front).f = [];

N = length(feasible);
M = size(f_all,2);

individual = [];
for i = 1:N
    id1 = feasible(i);
    individual(id1).N = 0;
    individual(id1).S = [];
end

% Assignging dominate flags
for i = 1:N
    id1 = feasible(i);
    f = repmat(f_all(i,:), N, 1);
    dom_less = sum(f <= f_all, 2);
    dom_more = sum(f >= f_all, 2);
    for j = 1:N
        id2 = feasible(j);
        if dom_less(j) == M && dom_more(j) < M
            individual(id1).S = [individual(id1).S id2];
        elseif dom_more(j) == M && dom_less(j) < M
            individual(id1).N = individual(id1).N + 1;
        end
    end
end

% identifying the first front
for i = 1:N
    id1 = feasible(i);
    if individual(id1).N == 0
        front_column(i,:) = 1;
        F(front).f = [F(front).f id1];
    end
end

% Identifying the rest of the fronts
while ~isempty(F(front).f)
    H = [];
    for i = 1 : length(F(front).f)
        p = F(front).f(i);
        if ~isempty(individual(p).S)
            for j = 1 : length(individual(p).S)
                q = individual(p).S(j);
                individual(q).N = individual(q).N - 1;
                if individual(q).N == 0
                    front_column(q,:)= front + 1;
                    H = [H q];
                end
            end
        end
    end
    if ~isempty(H)
        front = front+1;
        F(front).f = H;
    else
        break
    end
end
front_clm = sort(front_column);
return