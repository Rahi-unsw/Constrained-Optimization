function [f,g,x] = g1(objnum,x)
	if nargin == 1
		prob.nx = 13;
		prob.nf = 1;
		prob.ng = 9;
		for i = 1:9
			prob.range(i,:) = [0,1];
		end
		prob.range(10,:) = [0,100];
		prob.range(11,:) = [0,100];
		prob.range(12,:) = [0,100];
		prob.range(13,:) = [0,1];
		f = prob;
	else
		[f,g] = g1_true(objnum,x);
	end
end


function [f,g] = g1_true(objnum,x)
	f(:,objnum) = 5*sum(x(:,1:4),2) - 5*sum((x(:,1:4).*x(:,1:4)),2) - sum(x(:,5:13),2);
	g(:,1) = 10 - (2*x(:,1) + 2*x(:,2) + x(:,10) + x(:,11));
	g(:,2) = 10 - (2*x(:,1) + 2*x(:,3) + x(:,10) + x(:,12));
	g(:,3) = 10 - (2*x(:,2) + 2*x(:,3) + x(:,11) + x(:,12));
	g(:,4) = 8*x(:,1) - x(:,10);
	g(:,5) = 8*x(:,2) - x(:,11);
	g(:,6) = 8*x(:,3) - x(:,12);
	g(:,7) = 2*x(:,4) + x(:,5) - x(:,10);
	g(:,8) = 2*x(:,6) + x(:,7) - x(:,11);
	g(:,9) = 2*x(:,8) + x(:,9) - x(:,12);
    g = -1*g;
end
