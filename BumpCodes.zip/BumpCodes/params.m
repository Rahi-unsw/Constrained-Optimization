%% Problem Specific Input
% Problems with inequality constraints (g-series) are taken from CEC 2006 benchmarks. The references of engineering design problems are given in the paper. 
def.allprobs={'g1','g2','g4','g6','g7','g8','g9','g10','g12','g16','g18','g19','g24','b_spring','bulk_carrier_design','csi_so','helical_spring'};
% This algorithm is designed for single-objective constrained problems.
def.all_nf = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1];
% Population size = 50(Dimensions<10); Population size = 100(Dimensions>=10).
def.all_pop_size=[100,100,50,50,100,50,50,50,50,50,50,100,50,50,50,100,50];
% Maximum number of function evaluation(MNFE) = 10,000 (g-series) and 1,000 (engineering design problems).
% MNFE = def.pop_size*def.generation.
def.all_generation = [100,100,200,200,100,200,200,200,200,200,200,100,200,20,20,10,20];
% Number of trials for each problem.
def.no_runs = [21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21,21]; 
% Each trial is initiated from different set of sample points. 
def.seed_prob = 100*ones(length(def.allprobs),1); 
% Ranksum based approach considered in infeasibility driven ranking.
def.infeasible_strategy = 2; 
% Infeasible solutions ratio in the population.
def.infeasibility_ratio = 0.1; 
% For EFEA-FF Variant: 10% top ranked parents are used to create 10% child solutions
def.AlphaPerc = 0.1; 