%% Multirun: This function is used to run specified algorithms and problems across multiple trials. 
%  Set the parameters first at the params.m file properly.
%  Check that matlab path is added properly for all functions required (Check startup.m file)
%  Now Run the function.
%%
function multirun
clc;clear all;close all;warning off;
startup;
path=cd;
count=1;
params;

for i=1:numel(def.allprobs)
    for k=1:def.no_runs(i)
        disp(strcat('BumpCodes->',' Prob->',def.allprobs{i},' run-',num2str(k)));
        pth=strcat(cd,filesep,'Data',filesep,def.allprobs{i},filesep,'run-',num2str(k));
        mkdir(pth);
        cd(pth);
        def.problem_name=def.allprobs{i};
        def.nf=def.all_nf(i);
        def.seed=def.seed_prob(i)+k;
        def.generation=def.all_generation(i);
        def.pop_size=def.all_pop_size(i);
        save('Params.mat', 'def');
        path1{count} = pth;
        count = count+1;
        cd(path);
    end
end
cd(path);

% Run multiple parallel trials.
parfor i=1:length(path1)
    cd(path1{i});
    disp(strcat('Running -> ',path1{i}));
    param=load('Params.mat');
    tic; % Run time
    EFEA_FF(param.def,path1{i}); % Variants: BaseEA/BumpEA_FF/BumpEA_ID/EFEA_FF
    toc;
end
delete(gcp);
cd(path);
return